import sys
from PyQt5.QtWidgets import QApplication, QWidget
from laserspeckle_process.camera import Ui_widget
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QPixmap,QColor,QImage
from laserspeckle_process import camera_thread
import numpy as np
from matplotlib import cm,figure,pyplot
import cv2
from scipy import signal,ndimage
from PIL import Image

class App(QWidget):
    im = Image.open("5.bmp")
    #几个传递值的信号
    ExposuretimeChangedValue = pyqtSignal(int)
    GainChangedValue = pyqtSignal(int)


    def __init__(self):
            super(App,self).__init__()
            self.ui = Ui_widget()
            self.ui.setupUi(self)
            self.title = 'PyQt5 Video'

            self.initUI()

    def initUI(self):

            th = camera_thread.Thread(self)
            th.changePixmap.connect(lambda p: self.setPixMap(p))  # 将changePixmap 函数与setPixMap 函数 联系起来
            th.laser_posess.connect(lambda p: self.setLaserImage(p))#测试用

            #发送图片
            #截取图片
            self.ui.label_CaptureFrame.clicked.connect(th.capturePicture)
            #滑动条修改曝光时间
            self.ui.horizontalSlider_SetExposure.valueChanged.connect(self.on_changed_ExposureTime)
            self.ui.horizontalSlider_SetExposure.valueChanged.connect(th.CameraSettingChanged)
            self.ExposuretimeChangedValue.connect(lambda value: th.CameraSettingExposuretime(value))
            #滑动条修改帧率
            self.ui.horizontalSlider_Setfps.valueChanged.connect(th.CameraSettingChanged)
            #滑动条修改增益
            self.ui.horizontalSlider_SetGain.valueChanged.connect(th.CameraSettingChanged)
            self.ui.horizontalSlider_SetGain.valueChanged.connect(self.on_changed_Gain)
            self.GainChangedValue.connect(lambda value: th.CameraSettingExposuretime(value))

            #还差保持路径、截取间隔、还有截取时间
            #开启线程
            th.start()


    #修改相机曝光时间
    def on_changed_ExposureTime(self, value):
        Exposuretime = self.ui.horizontalSlider_SetExposure.value()
        print(Exposuretime)
        self.ExposuretimeChangedValue.emit(Exposuretime)
    #修改相机增益
    def on_changed_Gain(self, value):
        Gain = self.ui.horizontalSlider_SetGain.value()
        print(Gain)
        self.GainChangedValue.emit(Gain)
    #显示拍摄图片
    def setPixMap(self, p):
        p = QPixmap.fromImage(p)
        p = p.scaled(640, 480, Qt.KeepAspectRatio)
        self.ui.label_VideoDisplay.setPixmap(p)
    #显示激光散斑图像
    def setLaserImage(self, p):
        #变回mat格式

        mat = self.convertQImageToMat(p)

        ##这个暂时有一些问题
        # laser = self.im
        laser = self.laser_posess(mat, 5)
        # cv2.startWindowThread()
        # cv2.namedWindow("preview")
        # cv2.imshow("preview", laser)
        cv2.imwrite('111.jpg',laser)
        # laser = self.laser_posess(mat, 5)
        print(laser.shape[0])# 程序到这里是没有问题的
        laser.reshape(480,640,1)
        print(laser.shape)
        laser_qimage = QImage(laser.data, laser.shape[1],laser.shape[0], QImage.Format_Indexed8)#这里的QImage.Format_RGB16格式还需要再看看

        print(laser_qimage.size())
        #Indexed8
        p = QPixmap.fromImage(laser_qimage)
        p = p.scaled(640, 480, Qt.IgnoreAspectRatio)
        # p = self.cmap2pixmap(laser,'Reds', 50)
        # # 再转化为opencv里的图片格式，求完激光散斑再转Qimage显示
        self.ui.label_laserdisplay.setPixmap(p)

    #修改截取时间
    def convertQImageToMat(self,p):
        '''  Converts a QImage into an opencv MAT format  '''
        arr = p
        p = p.convertToFormat(3)
        ptr = p.bits()
        ptr.setsize(p.byteCount())
        arr = np.array(ptr)
        arr = np.array(ptr).reshape(p.height(), p.width(), 1)
        #不能用imshow,会中断信号，改用imwrite 方便查看

        print("convertQImageToMat Finished")
        return arr


##激光散斑处理
    def laser_posess(self,imarray, wsize):
        # imarray = cv2.cvtColor(imarray, cv2.COLOR_BGR2GRAY)
        # print(imarray.shape)
        imarray1 = imarray
        imarray1 = imarray.reshape(480,640)
        imarray1 = np.array(imarray1).astype(float)
        print(imarray1.shape)
        print(imarray1.dtype)  # 图像类型
        #JISUAN
        immean = ndimage.uniform_filter(imarray1, size=wsize)
        im2mean = ndimage.uniform_filter(np.square(imarray1), size=wsize)
        imcontrast = np.sqrt(abs(im2mean - np.square(immean)) / np.square(immean))
        print('speckle computation finished')
        imcontrast_show = imcontrast*255 #把（0，1）to （0，255）
        # print(np.max(imcontrast_show))
        # print(np.min(imcontrast_show))
        # print(imcontrast_show.shape)
        # print(imcontrast_show.dtype)  # 图像类型
        imcontrast_show = np.array(imcontrast_show).astype(int)
        imcontrast_show = imcontrast_show.reshape(480,640,1)
        # imcontrast_show = np.transpose(imcontrast_show, (1, 0, 2)).copy()
        print("laser_posess finished")
        return imcontrast_show

    #测试matplotlib to  qimage
    # def cmap2pixmap(self,img,cmap, steps):
    #     """Convert a maplotlib colormap into a QPixmap
    #     :param cmap: The colormap to use
    #     :type cmap: Matplotlib colormap instance (e.g. matplotlib.cm.gray)
    #     :param steps: The number of color steps in the output. Default=50
    #     :type steps: int
    #     :rtype: QPixmap
    #     """
    #     print('pass')
    #     sm = cm.ScalarMappable(cmap=cmap)
    #
    #     sm.norm.vmin = 0.0
    #     sm.norm.vmax = 1.0
    #     inds = np.linspace(0, 1, steps)
    #     rgbas = sm.to_rgba(inds)
    #     rgbas = [QColor(int(r * 255), int(g * 255),
    #                     int(b * 255), int(a * 255)).rgba() for r, g, b, a in rgbas]
    #     # im = QImage(steps, 1, QImage.Format_Indexed8)
    #     print('pass')
    #     im = QImage(img, img.shape[1], img.shape[0], QImage.Format_Indexed8)
    #     im.setColorTable(rgbas)
    #     pm = QPixmap.fromImage(im)
    #     return pm


    #colormap in qt
    # def testColourMap(cmap):
    #     sp = SubplotParams(left=0., bottom=0., right=1., top=1.)
    #     fig = pyplot.Figure((2.5, .2), subplotpars=sp)
    #     canvas = FigureCanvas(fig)
    #     ax = fig.add_subplot(111)
    #     gradient = np.linspace(0, 1, 256)
    #     gradient = np.vstack((gradient, gradient))
    #     ax.imshow(gradient, aspect=10, cmap=cmap)
    #     ax.set_axis_off()
    #     canvas.draw()
    #     size = canvas.size()
    #     width, height = size.width(), size.height()
    #     im = QImage(canvas.buffer_rgba(), width, height, QImage.Format_ARGB32)
    #     return QPixmap(im)

    # 定义一个函数来输出图片的一些属性
    # def get_image_info(image):
    #     print(type(image))  # 显示图片类型 numpy类型的数组
    #     # 图像矩阵的shape属性表示图像的大小，shape会返回tuple元组，第一个元素表示矩阵行数，第二个元组表示矩阵列数，第三个元素是3，表示像素值由光的三原色组成
    #     print(image.shape)
    #     print(image.size)  # 图像大小
    #     print(image.dtype)  # 图像类型
    #     pixel_data = np.array(image)
    #     print(pixel_data)  # 图片矩阵


if __name__ == '__main__':

    app = QApplication(sys.argv)
    ex = App()
    ex.show()
    sys.exit(app.exec_())